# SONAR — Projet Android Studio

## Ce que ce projet contient
- WebView optimisée pour audio en arrière-plan
- Sélection multiple de fichiers audio (même en APK)
- Pas de pull-to-refresh
- Contrôles écran de verrouillage (Media Session)
- Logo SONAR orange aux couleurs de l'app
- Notification de lecture persistante

---

## Installation étape par étape

### 1. Installer Android Studio
Télécharge Android Studio sur : https://developer.android.com/studio
- Installe-le normalement
- Au premier lancement, laisse-le télécharger le SDK Android (ça prend ~10 min)

### 2. Ouvrir le projet
- Lance Android Studio
- Clique "Open" (pas "New Project")
- Navigue vers le dossier SonarAndroid
- Clique OK et attends que Gradle sync se termine (barre en bas)

### 3. Générer l'APK
- Dans le menu en haut : Build → Build Bundle(s) / APK(s) → Build APK(s)
- Attends ~2 minutes
- Une notification apparaît "APK(s) generated successfully" → clique "locate"
- L'APK se trouve dans : app/build/outputs/apk/debug/app-debug.apk

### 4. Installer sur ton téléphone
- Connecte ton téléphone en USB
- Active le "Mode développeur" : Paramètres → À propos → appuie 7 fois sur "Numéro de build"
- Active "Débogage USB"
- Dans Android Studio clique le bouton ▶ Play en haut → sélectionne ton téléphone
- L'app s'installe automatiquement !

### Ou via fichier APK :
- Copie l'APK sur ton téléphone (USB ou email)
- Ouvre-le depuis le gestionnaire de fichiers
- Autorise les sources inconnues si demandé

---

## Structure du projet
```
SonarAndroid/
├── app/src/main/
│   ├── assets/index.html       ← Ton app SONAR complète
│   ├── java/com/sonar/music/
│   │   ├── MainActivity.java   ← WebView configurée
│   │   └── AudioBackgroundService.java ← Audio arrière-plan
│   ├── res/
│   │   ├── drawable/           ← Icônes
│   │   ├── mipmap-*/           ← Logo app
│   │   └── values/             ← Couleurs, styles
│   └── AndroidManifest.xml     ← Permissions
├── build.gradle
└── settings.gradle
```

---

## Problèmes courants

**"Gradle sync failed"** → File → Invalidate Caches → Restart

**"SDK not found"** → File → Project Structure → SDK Location → indique le chemin de ton SDK Android

**L'audio s'arrête en arrière-plan** → C'est normal au débogage USB. En APK installé ça fonctionne.
