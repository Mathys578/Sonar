# SONAR - Règles ProGuard
-keep class com.sonar.music.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
